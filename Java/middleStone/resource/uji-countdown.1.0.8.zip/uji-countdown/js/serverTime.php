﻿<?php 
$now = new DateTime(); 
echo $now->format("M j, Y H:i:s O")."\n"; 
?>